import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

import gen.*;
import parser.DMLErrorListener;
import parser.DMLReader;

//test parser reader with different inputs
class DMLReaderTest {
    String[] _validInput = {
            "INSERT INTO animals VALUES FROM (\"Spot\", \"dog\", 10);",
            "SHOW animals;",
            "CREATE TABLE species (kind VARCHAR(10)) PRIMARY KEY (kind);",
            "INSERT INTO species VALUES FROM RELATION PROJECT (kind) animals;",
            "WRITE animals;"
    };

    String[] _invalidInput = {"jalapeno",
            "Insert INto",
            "shoW ANIMALS",
            "close animAls",
            "omar testing"
    };

    @Test
    void read() {
        InputStream is = new ByteArrayInputStream(_validInput.toString().getBytes());
        DMLReader reader = new DMLReader();

        try {

            for (String s: _invalidInput) {
                DMLParser parser = reader.GetParser(s);
                Assertions.assertTrue(DMLErrorListener.HASERROR);
            }
            for (String s: _validInput) {
                DMLParser parser = reader.GetParser(s);
                assertFalse(DMLErrorListener.HASERROR);
            }
        } catch(IOException e) {

        }
    }
}
