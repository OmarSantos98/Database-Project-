package parser;

import gen.*;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

import java.io.*;


public class DMLReader {
    public DMLParser GetParser(String line) throws IOException {
        // Creating the lexer and parser from ANTLR
        CharStream stream = CharStreams.fromReader(new StringReader(line));
        DMLLexer lexer = new DMLLexer(stream);
        TokenStream tokenStream = new CommonTokenStream(lexer);
        DMLParser parser = new DMLParser(tokenStream);

        // For error checking
        DMLErrorListener.HASERROR = false;
        parser.removeErrorListeners();
        parser.addErrorListener(DMLErrorListener.INSTANCE);

        // Triggers the error update
        ParseTree tree = parser.program();
        return parser;
    }
}
