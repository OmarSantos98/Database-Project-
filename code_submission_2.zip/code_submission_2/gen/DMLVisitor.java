// Generated from C:/Users/andre/source/repos/315-P2-30/src\DML.g4 by ANTLR 4.7
package gen;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link DMLParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface DMLVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link DMLParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(DMLParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#string}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitString(DMLParser.StringContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#query}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuery(DMLParser.QueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#relationName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelationName(DMLParser.RelationNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression(DMLParser.ExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#atomicExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtomicExpression(DMLParser.AtomicExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#selection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelection(DMLParser.SelectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#condition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondition(DMLParser.ConditionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#conjunction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConjunction(DMLParser.ConjunctionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#comparison}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparison(DMLParser.ComparisonContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperator(DMLParser.OperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#operand}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperand(DMLParser.OperandContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#attributeName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttributeName(DMLParser.AttributeNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#projection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProjection(DMLParser.ProjectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#attributeList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttributeList(DMLParser.AttributeListContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#rename}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRename(DMLParser.RenameContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#union}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnion(DMLParser.UnionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#difference}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDifference(DMLParser.DifferenceContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#product}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProduct(DMLParser.ProductContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#naturalJoin}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNaturalJoin(DMLParser.NaturalJoinContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommand(DMLParser.CommandContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#open}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOpen(DMLParser.OpenContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#close}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClose(DMLParser.CloseContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#write}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrite(DMLParser.WriteContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#exit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExit(DMLParser.ExitContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#show}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShow(DMLParser.ShowContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#create}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate(DMLParser.CreateContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#update}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpdate(DMLParser.UpdateContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#insert}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInsert(DMLParser.InsertContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#delete}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDelete(DMLParser.DeleteContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#typedAttributeList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTypedAttributeList(DMLParser.TypedAttributeListContext ctx);
	/**
	 * Visit a parse tree produced by {@link DMLParser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType(DMLParser.TypeContext ctx);
}