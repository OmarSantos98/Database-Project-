package engine.condition;

import engine.exception.ColumnNotFoundException;

import java.util.List;

// TODO: Implement this for each type of conditional, and figure out what parameters should be used in Evaluate()
abstract public class Condition {
    protected String _columnName;
    protected Object _value;

    public Condition(String columnName, Object value) {
        _columnName = columnName;
        _value = value;
    }

    abstract public boolean Evaluate(List<String> columnNames, List<Object> tuple);
    protected int _getIndex(List<String> columnNames) {
        for(int i = 0; i < columnNames.size(); i++) {
            if(columnNames.get(i).equals(_columnName)) {
                return i;
            }
        }
        throw new ColumnNotFoundException();
    }
}