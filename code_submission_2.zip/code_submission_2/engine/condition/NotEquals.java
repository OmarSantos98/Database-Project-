package engine.condition;

import java.util.List;

//takes a column name and compares it to a value, returns the tuple that fits the criteria
public class NotEquals extends Condition {
    public NotEquals(String columnName, Object value) {
        super(columnName, value);
    }

    public boolean Evaluate(List<String> columnNames, List<Object> tuple) {
        if(tuple.size() != columnNames.size()) throw new RuntimeException("Row does not have the same number of values as columns");

        int index = _getIndex(columnNames);

        return tuple.get(index).equals(_value) == false;
    }
}
