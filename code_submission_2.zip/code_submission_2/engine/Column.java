package engine;

public class Column {
    public String Name;
    public ColumnType Type;
    public boolean IsPrimaryKey;
    public int Length;
    public int Index;

    public Column(String name, ColumnType type, boolean isPrimaryKey) {
        Name = name;
        Type = type;
        IsPrimaryKey = isPrimaryKey;
    }

    public Column(String name, ColumnType type, boolean isPrimaryKey, int length) {
        Name = name;
        Type = type;
        IsPrimaryKey = isPrimaryKey;
        Length = length;
    }
    public Column(String name, ColumnType type, boolean isPrimaryKey, int length, int index) {
        Name = name;
        Type = type;
        IsPrimaryKey = isPrimaryKey;
        Length = length;
        Index = index;
    }

    public Column(Column old) {
        Name = old.Name;
        Type = old.Type;
        IsPrimaryKey = old.IsPrimaryKey;
        Length = old.Length;
        Index = old.Index;
    }
    
//gets column type
    public String GetType() {
        String ret = Type.toString();
        if(Type == ColumnType.VARCHAR) ret += Length;
        return ret;
    }

    @Override
    public String toString() {
        String ret = Name + ":" + Type;
        if(Type == ColumnType.VARCHAR) ret += Length;
        ret += ":" + IsPrimaryKey;
        return ret;
    }

    //checks if two columns are the same
    @Override
    public boolean equals(Object other) {
        if(!(other instanceof Column)) return false;
        Column c = (Column)other;
        return Name.equals(c.Name)
                && Type.equals(c.Type)
                && Length == c.Length;
    }
}
