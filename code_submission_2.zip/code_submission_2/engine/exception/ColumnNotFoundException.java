package engine.exception;

public class ColumnNotFoundException extends DatabaseCoreException {
    public ColumnNotFoundException() {
        super("Column Not Found");
    }
}
