package engine.exception;

public class InvalidColumnCountException extends DatabaseCoreException {
    public InvalidColumnCountException() {
        super("Invalid column count");
    }
}
