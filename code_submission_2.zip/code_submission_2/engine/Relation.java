package engine;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.stream.Collectors.joining;

//initiates relation and values it holds
public class Relation {
    private String _name;
    private Map<String, Column> _columnsByName;
    private Map<Integer, Column> _columnsByIndex;
    private List<List<Object>> _table;

    public Relation() {
        _columnsByName = new LinkedHashMap<>();
        _columnsByIndex = new HashMap<>();
        _table = new ArrayList<>();
    }

    public Relation(String name) {
        _name = name;
        _columnsByName = new LinkedHashMap<>();
        _columnsByIndex = new HashMap<>();
        _table = new ArrayList<>();
    }

    private boolean isNewValue(int index, Object value) {
        for (List<Object> tuple: _table) if(tuple.get(index).equals(value)) return false;
        return true;
    }
    public String GetName() {
        return _name;
    }
    //gets number of rows as an int
    public int Size() { return _table.size(); }

    public List<List<Object>> GetRows() {
        return _table;
    }
    public List<List<Object>> GetRowsForCopy() {
        List<List<Object>> ret = new ArrayList<>();

        for (List<Object> row: _table) {
            List<Object> newRow = new ArrayList<>(row);
            ret.add(newRow);
        }

        return ret;
    }
    //returns desired row
    public List<Object> GetRow(int index) {
        return _table.get(index);
    }
    //adds row to relation
    public void AddRow(List<Object> values) {
        Object objs[] = new Object[values.size()];
        values.toArray(objs);
        this.AddRow(objs);
    }
    //adds row to relation
    public void AddRow(Object... values) {
        try {
            if (values.length != _columnsByName.size()) {
                String error = "Row does not have the proper number of columns.";
                error += "\nRow column count: " + values.length;
                error += "\nAccurate column count: " + _columnsByName.size();
                error += "\n" + Arrays.asList(values);
                System.out.println(error);
                return;
            }
            List<Object> toAdd = new ArrayList<>();

            // Check Primary Key Constraints
            boolean isUniqueFlag = true;
            for (Column c: _columnsByName.values())
                if(c.IsPrimaryKey && isNewValue(c.Index, values[c.Index]) == false) {
                    isUniqueFlag = false;
                    break;
                }

            if(isUniqueFlag == false) {
                System.out.println(values + " did not use a unique primary key.");
                return;
            }

            // Actually add the row
            for(int i = 0; i < values.length; i++) {
                Column column = _columnsByIndex.get(i);
                if(column.Type == ColumnType.INTEGER)
                {
                    Integer t = Integer.parseInt(values[i].toString());
                    toAdd.add(t);
                }
                else {
                    String s = (String)values[i];

                    // Truncating based on VARCHAR restrictions
                    s = s.substring(0, Math.min(column.Length, s.length()));
                    toAdd.add(s);
                }
            }
            _table.add(toAdd);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }
    }
    public void AddRows(List<List<Object>> rows) {
        _table.addAll(rows);
    }

    public List<List<Object>> GetNewRows(List<Column> columnData) {
        List<List<Object>> subList = new ArrayList<>();
        int columnSize = columnData.size();
        for (int index = 0; index < _table.size(); index++) {
            List<Object> toAdd = new ArrayList<>();
            for (int j = 0; j < columnSize; j++) {
                int columnIndex = columnData.get(j).Index;
                toAdd.add(_table.get(index).get(columnIndex));
            }
            subList.add(toAdd);
        }
        return subList;
    }


//deletes row of relation at index number
    public void DeleteRows(List<Integer> indices) {
        //checks the table at each int in the indices list, and if they are equal
        // t deletes that area
        for (int index = 0; index < _table.size(); index++) {
            for (int j = 0; j < indices.size(); j++) {
                if (indices.get(j) == index) {
                    _table.remove(_table.get(index));
                }
            }
        }
    }
    //checks for specific row
    public boolean HasRow(List<Object> row) {
        if(row.size() != _columnsByName.size()) throw new RuntimeException();

        for (List<Object> tuple: _table) {
            boolean ret = false;
            for (int i = 0; i < tuple.size(); i++) {
                ret = tuple.get(i).equals(row.get(i));
                if(ret == false) break;
            }
            if(ret == true) return true;
        }
        return false;
    }

    public void SetColumns(String... names) {
        for (int i = 0; i < names.length; i++) {
            String[] attributes =  names[i].split(":");

            // Column properties
            ColumnType type = ColumnType.VARCHAR;
            int length = 0;
            boolean isPrimaryKey = Boolean.parseBoolean(attributes[2]);

            if(attributes[1].equals("INTEGER")) type = ColumnType.INTEGER;
            else {
                Pattern p = Pattern.compile("\\d+");
                Matcher m = p.matcher(attributes[1]);
                m.find();
                length = Integer.parseInt(m.group(0));
            }

            Column c = new Column(attributes[0], type, isPrimaryKey, length, i);
            _columnsByIndex.put(i, c);
            _columnsByName.put(attributes[0], c);
        }
    }
    public void SetColumns(List<Column> columns) {
        for (int i = 0; i < columns.size(); i++) {
            Column c = columns.get(i);
            c.Index = i;
            if(_columnsByName.containsKey(c.Name)) {
                _columnsByName.put(c.Name + "1", c);
            }
            else _columnsByName.put(c.Name, c);
            _columnsByIndex.put(c.Index, c);
        }
    }
    //copies whole column
    public String[] CopyColumns() {
        String[] ret = new String[_columnsByName.size()];
        Column[] columns = (Column[]) _columnsByName.values().toArray();
        for (int i = 0; i < columns.length; i++) {
            ret[i] = columns[i].toString();
        }

        return ret;
    }
    public boolean HasColumn(Column column) { return _columnsByName.containsKey(column.Name) && _columnsByName.get(column.Name).equals(column); }
    public void RenameColumn(String columnName, String newName) {
        if(!_columnsByName.containsKey(columnName)) throw new RuntimeException();
        _columnsByName.get(columnName).Name = newName;
    }
    public Column GetColumn(String name) {
        return _columnsByName.get(name);
    }
    public Column GetColumn(Integer index) {
        return _columnsByIndex.get(index);
    }
    public List<Column> GetColumns() {
        List<Column> ret = new ArrayList<>();
        ret.addAll(_columnsByName.values());
        return ret;
    }
    public List<String> GetColumnNames() {
        List<String> ret = new ArrayList<>();
        ret.addAll(_columnsByName.keySet());
        return ret;
    }
    public int GetColumnCount() { return _columnsByName.size(); }
}
