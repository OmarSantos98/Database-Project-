package engine;

import engine.condition.Condition;
import engine.exception.ColumnNotFoundException;
import engine.exception.InvalidColumnCountException;
import javafx.util.Pair;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.util.stream.Collectors.joining;

public class DatabaseCore {
    private String _relationsPath = "relations/";

    // Commands
    //open relation file
    public Relation Open(String relationName) {
        Relation ret = new Relation(relationName);

        try{
            BufferedReader br = new BufferedReader(new FileReader(_relationsPath + relationName + ".db"));
            String line = br.readLine();

            ret.SetColumns(line.split(","));
            while((line = br.readLine()) != null) {
                ret.AddRow(line.split(","));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return ret;
    }
        //take a non existing relation and write to file
    public boolean Write(Relation relation) {
        Path fullPath = Paths.get(_relationsPath + relation.GetName() + ".db");
        List<String> writes = new ArrayList<>();
        try {

            String columnHeader = relation.GetColumns().stream().map(c -> c.toString()).collect(joining(","));
            writes.add(columnHeader);

            for (List<Object> row: relation.GetRows()) writes.add(row.stream().map(Object::toString).collect(joining(",")));
            Files.write(fullPath, writes, StandardOpenOption.CREATE_NEW);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    //take existing relation and write to file
    public boolean Close(Relation relation) {
        Path fullPath = Paths.get(_relationsPath + relation.GetName() + ".db");
        List<String> writes = new ArrayList<>();
        try{
            String columnHeader = relation.GetColumns().stream().map(c -> c.toString()).collect(joining(","));
            writes.add(columnHeader);

            for (List<Object> row: relation.GetRows()) writes.add(row.stream().map(Object::toString).collect(joining(",")));

            Files.write(fullPath, writes, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    public void Exit() {
        System.exit(0);
    }
    //shows relation(table)
    public void Show(Relation relation) {
        // Prints column names
        System.out.println(relation.GetColumns().stream().map(c -> c.Name).collect(joining(" ")));
        // Prints actual relation
        for (List<Object> row: relation.GetRows()) System.out.println(row.stream().map(Object::toString).collect(joining(" ")));
    }
    //create relation (table)
    public Relation Create(String relationName, List<Column> typedAttributeList) {
        Relation relation = new Relation(relationName);
        relation.SetColumns(typedAttributeList);
        return relation;
    }
    //change relation based on condition
    public boolean Update(Relation relation, Condition condition, List<Pair<String, Object>> attributeLiteralPairs) {
        for (List<Object> row: relation.GetRows()) {
            if(condition.Evaluate(relation.GetColumnNames(), row)) {
                for (Pair<String, Object> pair: attributeLiteralPairs) {
                    int columnIndex = relation.GetColumn(pair.getKey()).Index;
                    row.set(columnIndex, pair.getValue());
                }
            }
        }
        return true;
    }

    public boolean Insert(Relation relation, List<Object> lits) {
        if(lits.size() != relation.GetColumnCount()) throw new RuntimeException();

        relation.AddRow(lits);

        return true;
    }
    //insert a row of a relation(table) into another relation
    public boolean Insert(Relation relation, Relation newRelation) {
        if(newRelation.GetColumnCount() != relation.GetColumnCount()) throw new InvalidColumnCountException();

        relation.AddRows(newRelation.GetRowsForCopy());

        return true;
    }

    //delete row of a relation (table) based on a condition
    public boolean Delete(Relation relation, Condition condition) {
        List<Integer> deleting = new ArrayList<>();
        for (int i = 0; i < relation.Size(); i++)  {
            if (condition.Evaluate(relation.GetColumnNames(), relation.GetRow(i))) { 
                deleting.add(i);
            }
        }
        relation.DeleteRows(deleting);
        return true;
    }
    // Queries
    
    // Selection is used to select tuples that pass a condition from a relation
    public Relation Select(Relation relation, Condition condition){
        Relation ret = new Relation();
        List<Column> columns = new ArrayList<>();
        columns.addAll(relation.GetColumns());
        ret.SetColumns(columns);
        for (int i = 0; i < relation.Size(); i++) {
            List<Object> row = relation.GetRow(i);
            if(condition.Evaluate(ret.GetColumnNames(), row))
                ret.AddRow(row);
        }
        return ret;
    }
    
    // Projection is used to get specified column data from a relation
    public Relation Project(Relation relation, List<String> attributeNames) {
        Relation ret = new Relation();
        List<Column> columns = relation.GetColumns()
                .stream()
                .filter(c -> attributeNames.contains(c.Name) == true)
                .collect(Collectors.toList());

        ret.SetColumns(columns);
        ret.AddRows(relation.GetNewRows(columns));
        return ret;
    }
    
    // Will rename all column names to the new list of column names
    public Relation Rename(Relation relation, List<String> columnNames) {
        Relation ret = new Relation();
        if(relation.GetColumns().size() != columnNames.size()) throw new InvalidColumnCountException();

        List<Column> columns = new ArrayList<>();
        for (int i = 0; i < columnNames.size(); i++) {
            Column c = new Column(relation.GetColumn(i));
            c.Name = columnNames.get(i);
            columns.add(c);
        }
        ret.SetColumns(columns);
        ret.AddRows(relation.GetRowsForCopy());

        return ret;
    }
    
    //The union of two sets is a new set that contains all of the elements that are in at least one of the two sets
    public Relation Union(Relation r1, Relation r2) {
        if(r1.GetColumnCount() != r2.GetColumnCount()) throw new RuntimeException();
        for (Column c: r1.GetColumns()) if (r2.HasColumn(c) == false) throw new ColumnNotFoundException();

        Relation ret = new Relation();
        ret.SetColumns(r1.GetColumns());
        for (int i = 0; i < r1.Size(); i++) {
            ret.AddRow(r1.GetRow(i));
        }

        for (int i = 0; i < r2.Size(); i++) {
            List<Object> row = r2.GetRow(i);
            if(ret.HasRow(row) == false) ret.AddRow(row);
        }

        return ret;
    }
    
    
    //Let S and T be sets such that:
    
   // S={1,2,3}
    //T={2,4,5,6}
    //Let ∖ denote set difference.
    //S∖T={1,3}

    public Relation Difference(Relation r1, Relation r2) {
        if(r1.GetColumnCount() != r2.GetColumnCount()) throw new RuntimeException();
        for (Column c: r1.GetColumns()) if (r2.HasColumn(c) == false) throw new ColumnNotFoundException();

        Relation ret = new Relation();
        ret.SetColumns(r1.GetColumns());
        for (int i = 0; i < r1.Size(); i++) {
            List<Object> row = r1.GetRow(i);
            if(r2.HasRow(row) == false) ret.AddRow(row);
        }

        return ret;
    }
    
    //  Cross product between two relations let say A and B, so cross product between A X B will results all the attributes of A followed by each attribute of B. Each record of A will pairs with every record of B.
    
    public Relation Product(Relation r1, Relation r2) {
        Relation ret = new Relation();
        List<Column> columns = r1.GetColumns();
        columns.addAll(r2.GetColumns());
        
        ret.SetColumns(columns);
        System.out.println(ret.GetColumnNames());
        for (int i = 0; i < r1.Size(); i++) {
            for (int j = 0; j < r2.Size(); j++) {
                List<Object> row = new ArrayList<>(r1.GetRow(i));
                row.addAll(r2.GetRow(j));
                ret.AddRow(row);
            }
        }

        return ret;
    }
    
    //Natural join is a binary operator. Natural join between two or more relations will result set of all combination of tuples where they have equal common attribute.
    
    public Relation NaturalJoin(Relation r1, Relation r2) {
        Column common = null;
        for (int i = 0; i < r1.GetColumnCount(); i++) {
            if(r2.HasColumn(r1.GetColumn(i))) {
                common = r1.GetColumn(i);
                break;
            }
        }

        if(common == null) throw new RuntimeException("No common column names");

        // Get proper number of columns
        List<Column> columns = new ArrayList<>();
        columns.addAll(r1.GetColumns());
        for(Column c: r2.GetColumns()) {
            if(c.equals(common)) continue;
            columns.add(c);
        }

        Relation ret = new Relation();
        ret.SetColumns(columns);

        // Properly append tuple values
        int index1 = r1.GetColumn(common.Name).Index;
        int index2 = r2.GetColumn(common.Name).Index;

        for (int i = 0; i < r1.Size(); i++) {
            List<Object> row1 = r1.GetRow(i);

            for (int j = 0; j < r2.Size(); j++) {
                List<Object> row2 = r2.GetRow(j);
                // Comparing
                if(row1.get(index1) == row2.get(index2)) {
                    List<Object> row = new ArrayList<>();
                    // For the first relation
                    row.addAll(row1);
                    // For the second relation
                    row.addAll(IntStream.range(0, r2.GetColumnCount())
                            .filter(in -> in != index2)
                            .mapToObj(r2.GetRow(j)::get)
                            .collect(Collectors.toList()));
                    ret.AddRow(row);
                }
            }
        }

        return ret;
    }
}
