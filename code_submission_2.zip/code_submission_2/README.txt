/* READ ME */

Project 2.3 Makefile
Compile and Run Instructions: 

Login to the tamu server (compute.cs.tamu.edu):

In terminal (on mac)
ssh -Y NETID@compute.cse.tamu.edu
Enter password 

Change directory to code_submission_2

Tests are provided in Main.java. To run the the tests, type the following:

javac *.java 
java Main


Each function was provided with an individual test by creating new relations or using
relations made by previous functions. 

-Group 30


GitHub Project Development Log: 
https://github.tamu.edu/joey-whitmore1997/315-P2-30/wiki/Development-log