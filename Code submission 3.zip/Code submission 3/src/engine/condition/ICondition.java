package engine.condition;

import java.util.List;

public interface ICondition {
    boolean Evaluate(List<String> columnNames, List<Object> tuple);
}