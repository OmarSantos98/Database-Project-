package engine.condition;

import engine.exception.ColumnNotFoundException;
import engine.exception.DatabaseCoreException;
import gen.DMLParser;

import java.util.Arrays;
import java.util.List;

import static java.util.stream.Collectors.joining;

public class Condition implements ICondition {
    DMLParser.ConditionContext _condition;

    public Condition(DMLParser.ConditionContext condition) {
        _condition = condition;
    }

    @Override
    public boolean Evaluate(List<String> columnNames, List<Object> tuple) {
        for (DMLParser.ConjunctionContext conj : _condition.conjunction()) {
            if (conjunction(conj, columnNames, tuple) == true) {
                return true;
            }
        }
        return false;
    }

    private boolean conjunction(DMLParser.ConjunctionContext conj, List<String> columnNames, List<Object> tuple) {
        for (DMLParser.ComparisonContext comp : conj.comparison()) {
            if (!comparison(comp, columnNames, tuple)) {
                return false;
            }
        }
        return true;
    }

    private boolean comparison(DMLParser.ComparisonContext comp, List<String> columnNames, List<Object> tuple) {
        if (comp.condition() != null) {
            Condition newOne = new Condition(comp.condition());
            return newOne.Evaluate(columnNames, tuple);
        }
        try {
            if (comp.operator().getText().equals("==")) {
                return getValue(comp.operand(0), columnNames, tuple).equals(getValue(comp.operand(1), columnNames, tuple));
            } else if (comp.operator().getText().equals("!=")) {
                return !getValue(comp.operand(0), columnNames, tuple).equals(getValue(comp.operand(1), columnNames, tuple));
            } else {
                // They must be integers
                Integer i0 = Integer.parseInt(getValue(comp.operand(0), columnNames, tuple));
                Integer i1 = Integer.parseInt(getValue(comp.operand(1), columnNames, tuple));

                switch (comp.operator().getText()) {
                    case "<": {
                        return i0 < i1;
                    }
                    case ">": {
                        return i0 > i1;
                    }
                    case "<=": {
                        return i0 <= i1;
                    }
                    case ">=": {
                        return i0 >= i1;
                    }
                }
            }
        } catch (DatabaseCoreException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    private String getValue(DMLParser.OperandContext op, List<String> columnNames, List<Object> tuple) {
        if (op.attributeName() != null) {
            String name = op.attributeName().getText();
            int index = columnNames.indexOf(name);
            if (index < 0) throw new ColumnNotFoundException(name);
            return tuple.get(index).toString();
        }
        return getUnquoted(op.string().getText());
    }

    private String getUnquoted(String s) {
        if(s.matches("\".*\"")) {
            return s.replaceAll("\"", "");
        }
        return s;
    }
}
