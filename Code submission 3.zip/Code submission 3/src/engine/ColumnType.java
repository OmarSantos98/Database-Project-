package engine;

//possible types of columns
public enum ColumnType {
    INTEGER,
    VARCHAR
}
