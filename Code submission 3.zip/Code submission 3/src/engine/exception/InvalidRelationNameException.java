package engine.exception;

public class InvalidRelationNameException extends DatabaseCoreException {
    public InvalidRelationNameException(String name) {
        super("\"" + name + "\" is an invalid relation name.");
    }
}
