package engine.exception;

public class ColumnNotFoundException extends DatabaseCoreException {
    public ColumnNotFoundException() {
        super("Column Not Found");
    }
    public ColumnNotFoundException(String columnName) {
        super("\"" + columnName + "\" could not be found.");
    }
}
