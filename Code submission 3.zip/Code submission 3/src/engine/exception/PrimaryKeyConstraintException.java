package engine.exception;

public class PrimaryKeyConstraintException extends DatabaseCoreException {
    public PrimaryKeyConstraintException(String relationName) {

        super("This violated the primary key constraints on \"" + relationName + "\"");
    }
}
