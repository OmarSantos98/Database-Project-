package engine.exception;

public class EmptyStackException extends DatabaseCoreException {
    public EmptyStackException() {
        super("The stack is empty.");
    }
}
