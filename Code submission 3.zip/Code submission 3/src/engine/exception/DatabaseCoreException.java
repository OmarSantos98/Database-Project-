package engine.exception;

public class DatabaseCoreException extends RuntimeException {
    public DatabaseCoreException() {
        super();
    }
    public DatabaseCoreException(String s) {
        super(s);
    }
    public DatabaseCoreException(String s, Throwable throwable) {
        super(s, throwable);
    }
    public DatabaseCoreException(Throwable throwable) {
        super(throwable);
    }
}