import engine.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DatabaseCoreTest {
    private DatabaseCore core;

    @BeforeEach
    void setUp() {
        core = new DatabaseCore();
    }
//testing open command
    @Test
    void open() {
        Relation test = core.Open("test");

        List<Object> row0 = test.GetRow(0);
        assertEquals(row0.get(0), "0");
        assertEquals(row0.get(1), 1);

        List<Object> row1 = test.GetRow(1);
        assertEquals(row1.get(0), "2");
        assertEquals(row1.get(1), 3);
    }

    //testing write command
    @Test
    void write() {
        Relation write = new Relation("write-test");
        write.SetColumns("column1:" + ColumnType.INTEGER + ":0", "column2:" + ColumnType.INTEGER + ":true");

        for (int i = 0; i < 30; i++) write.AddRow(i, i + 1);
        assertTrue(core.Write(write));

        Relation test = core.Open("write-test");
        assertEquals(test.GetColumns().get(0).Name, "column1");
        assertEquals(test.GetColumns().get(1).Name, "column2");
        List<List<Object>> data = test.GetRows();
        for (int i = 0; i < 30; i++) {
            assertEquals(data.get(i).get(0), i);
            assertEquals(data.get(i).get(1), i + 1);
        }
    }
//teting close command
    @Test
    void close() {
    }

    //testing exi command
    @Test
    void exit() {
    }
//testing show command
    @Test
    void show() {}
}
