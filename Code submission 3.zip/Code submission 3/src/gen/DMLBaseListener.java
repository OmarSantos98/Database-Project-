// Generated from C:/Users/andre/source/repos/315-P2-30/src\DML.g4 by ANTLR 4.7
package gen;

import engine.*;
import engine.condition.Condition;

import engine.exception.EmptyStackException;
import engine.exception.InvalidRelationNameException;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

import java.util.*;

public class DMLBaseListener implements DMLListener {

    private DatabaseCore core = new DatabaseCore();
    private Map<String, Relation> relations = new HashMap<>();
    private Stack<Relation> stack = new Stack<>(); // Use Carefully
    // ------------ helpers -------------- //
    private Relation pop() {
        if(stack.empty()) throw new EmptyStackException();
        return stack.pop();
    }
    private String getValue(String s) {
        if(s.matches("\".*\"")) {
            return s.replaceAll("\"", "");
        }
        return s;
    }

    // --------------------- QUERY ---------------------- //
    @Override
    public void enterQuery(DMLParser.QueryContext ctx) {
    }

    @Override
    public void exitQuery(DMLParser.QueryContext ctx) {
        Relation relation;
        String relationName = ctx.relationName().getText();

        if(ctx.expression().atomicExpression() != null)
        {
            relation = new Relation(relationName);
            Relation temp = relations.get(ctx.expression().atomicExpression().relationName().getText());
            relation.SetColumns(temp.GetColumns());
            relation.AddRows(temp.GetRowsForCopy());
        }
        else
            relation = pop();

        relation.SetName(relationName);
        relations.put(relation.GetName(), relation);
    }

    // --------------------- SELECT --------------------- //
    @Override
    public void enterSelection(DMLParser.SelectionContext ctx) {
    }

    @Override
    public void exitSelection(DMLParser.SelectionContext ctx) {
        Relation relation;
        Relation selection;

        if (ctx.atomicExpression().expression() != null) relation = pop();
        else relation = relations.get(ctx.atomicExpression().relationName().getText());

        // Error checking
        if (relation == null) throw new InvalidRelationNameException(ctx.atomicExpression().relationName().getText());

        selection = core.Select(relation, new Condition(ctx.condition()));

        stack.push(selection);
    }


    // --------------------- PROJECTION ----------------- //
	@Override public void enterProjection(DMLParser.ProjectionContext ctx) { }
	@Override public void exitProjection(DMLParser.ProjectionContext ctx) { 
			Relation relation;
			if (ctx.atomicExpression().expression() != null) relation = pop();
			else relation = relations.get(ctx.atomicExpression().relationName().getText());

			if(relation == null) throw new InvalidRelationNameException(ctx.atomicExpression().relationName().getText());

			List<String> attributes = new ArrayList<>();
			for (int index = 0; index < ctx.attributeList().attributeName().size(); index++) {
				attributes.add(ctx.attributeList().attributeName(index).getText());
			}
			stack.push(core.Project(relation, attributes));
	 	}

    // --------------------- RENAME --------------------- //
    @Override
    public void enterRename(DMLParser.RenameContext ctx) { }

    @Override
    public void exitRename(DMLParser.RenameContext ctx) {
        Relation relation;
        if (ctx.atomicExpression().expression() != null) relation = pop();
        else relation = relations.get(ctx.atomicExpression().relationName().getText());

        if(relation == null) throw new InvalidRelationNameException(ctx.atomicExpression().relationName().getText());

        List<String> attributes = new ArrayList<>();
        for (int index = 0; index < ctx.attributeList().attributeName().size(); index++) {
            attributes.add(ctx.attributeList().attributeName(index).getText());
        }
        stack.push(core.Rename(relation, attributes));
    }

    // --------------------- UNION ---------------------- //
    @Override
    public void enterUnion(DMLParser.UnionContext ctx) {
    }

    @Override
    public void exitUnion(DMLParser.UnionContext ctx) {
        Relation left;
        Relation right;
        Relation union;
        // Get the right first, since it should be at the top of the stack
        // RIGHT: Must be a relation to union on
        if (ctx.atomicExpression(1).relationName() != null)
            right = relations.get(ctx.atomicExpression(1).relationName().getText());
        else
            right = pop();

        if (ctx.atomicExpression(0).relationName() != null)
            left = relations.get(ctx.atomicExpression(0).relationName().getText());
        else
            left = pop();

        if(right == null) throw new InvalidRelationNameException(ctx.atomicExpression(1).relationName().getText());
        if(left == null) throw new InvalidRelationNameException(ctx.atomicExpression(0).relationName().getText());

        union = core.Union(left, right);
        stack.push(union);
    }

    // --------------------- DIFFERENCE ----------------- //
	
    @Override
    public void enterDifference(DMLParser.DifferenceContext ctx) {}

	@Override
	public void exitDifference(DMLParser.DifferenceContext ctx) {
		    Relation left;
		    Relation right;
		    Relation dif;

		    System.out.println("Difference");
		    if (ctx.atomicExpression(1).relationName() != null)
		        right = relations.get(ctx.atomicExpression(1).relationName().getText());
		    else
		        right = pop();

		    if (ctx.atomicExpression(0).relationName() != null)
		        left = relations.get(ctx.atomicExpression(0).relationName().getText());
		    else
		        left = pop();

		    if(right == null) throw new InvalidRelationNameException(ctx.atomicExpression(1).relationName().getText());
		    if(left == null) throw new InvalidRelationNameException(ctx.atomicExpression(0).relationName().getText());

		        dif = core.Difference(left, right);
		        stack.push(dif);
	    
    }
		

    // --------------------- PRODUCT -------------------- //
    @Override
    public void enterProduct(DMLParser.ProductContext ctx) { }

    @Override
    public void exitProduct(DMLParser.ProductContext ctx) {
        Relation left;
        Relation right;
        Relation prod;

        if (ctx.atomicExpression(1).relationName() != null)
            right = relations.get(ctx.atomicExpression(1).relationName().getText());
        else
            right = pop();

        if (ctx.atomicExpression(0).relationName() != null)
            left = relations.get(ctx.atomicExpression(0).relationName().getText());
        else
            left = pop();

        if(right == null) throw new InvalidRelationNameException(ctx.atomicExpression(1).relationName().getText());
        if(left == null) throw new InvalidRelationNameException(ctx.atomicExpression(0).relationName().getText());

        prod = core.Product(left, right);
        stack.push(prod);
    }

    // --------------------- NATURALJOIN ---------------- //
    @Override
    public void enterNaturalJoin(DMLParser.NaturalJoinContext ctx) {
      

    }

    @Override
    public void exitNaturalJoin(DMLParser.NaturalJoinContext ctx) {
        Relation left;
        Relation right;
        Relation njoin;
        
        System.out.println("Natural Join");
        if (ctx.atomicExpression(1).relationName() != null)
            right = relations.get(ctx.atomicExpression(1).relationName().getText());
        else
            right = pop();
        
        if (ctx.atomicExpression(0).relationName() != null)
            left = relations.get(ctx.atomicExpression(0).relationName().getText());
        else
            left = pop();
        
        if(right == null) throw new InvalidRelationNameException(ctx.atomicExpression(1).relationName().getText());
        if(left == null) throw new InvalidRelationNameException(ctx.atomicExpression(0).relationName().getText());
        
        njoin = core.NaturalJoin(left, right);
        stack.push(njoin);
    }

    // --------------------- OPEN ----------------------- //
    @Override
    public void enterOpen(DMLParser.OpenContext ctx) {
        Relation relation = core.Open(ctx.relationName().getText());
        if(relation == null) throw new InvalidRelationNameException(ctx.relationName().getText());
        relations.put(relation.GetName(), relation);
    }

    @Override
    public void exitOpen(DMLParser.OpenContext ctx) {
    }

    // --------------------- CLOSE ---------------------- //
    @Override
    public void enterClose(DMLParser.CloseContext ctx) {
        Relation relation = relations.remove(ctx.relationName().getText());
        if(relation == null) throw new InvalidRelationNameException(ctx.relationName().getText());
        core.Close(relation);
    }

    @Override
    public void exitClose(DMLParser.CloseContext ctx) {
    }

    // --------------------- WRITE ---------------------- //
    @Override
    public void enterWrite(DMLParser.WriteContext ctx) {
        Relation relation = relations.get(ctx.relationName().getText());
        if(relation == null) throw new InvalidRelationNameException(ctx.relationName().getText());
        core.Write(relation);
    }

    @Override
    public void exitWrite(DMLParser.WriteContext ctx) {
    }

    // --------------------- EXIT ----------------------- //
    @Override
    public void enterExit(DMLParser.ExitContext ctx) {
        core.Exit();
    }

    @Override
    public void exitExit(DMLParser.ExitContext ctx) {
    }

    // --------------------- SHOW ----------------------- //
    @Override
    public void enterShow(DMLParser.ShowContext ctx) {
        Relation relation = relations.get(ctx.relationName().getText());
        if (relation == null) throw new InvalidRelationNameException(ctx.relationName().getText());
        core.Show(relation);
    }

    @Override
    public void exitShow(DMLParser.ShowContext ctx) {
    }

    // --------------------- CREATE ---------------------- //
    @Override
    public void enterCreate(DMLParser.CreateContext ctx) {
        List<Column> typedAttributeList = new ArrayList<>();

        // Create Columns from ctx
        DMLParser.TypedAttributeListContext typedAttributes = ctx.typedAttributeList();
        for (int i = 0; i < typedAttributes.attributeName().size(); i++) {
            DMLParser.AttributeNameContext attribute = typedAttributes.attributeName(i);
            // Name
            String name = attribute.getText();

            // Types
            DMLParser.TypeContext t = typedAttributes.type(i);
            ColumnType type = (t.getText().equals("INTEGER")) ? ColumnType.INTEGER : ColumnType.VARCHAR;

            // Primary Key
            boolean isPrimaryKey = ctx.attributeList().attributeName().stream().anyMatch(a -> a.getText().equals(name));

            Column column = new Column(name, type, isPrimaryKey);
            if (type == ColumnType.VARCHAR) column.Length = Integer.parseInt(t.INTEGER().getText());
            typedAttributeList.add(column);
        }

        Relation relation = core.Create(ctx.relationName().getText(), typedAttributeList);
        relations.put(relation.GetName(), relation);
    }

    @Override
    public void exitCreate(DMLParser.CreateContext ctx) { }

    // --------------------- UPDATE ---------------------- //
    @Override
    public void enterUpdate(DMLParser.UpdateContext ctx) {
        Relation relation = relations.get(ctx.relationName().getText());
        if(relation == null) throw new InvalidRelationNameException(ctx.relationName().getText());
        List<KeyValue<String, String>> pairs = new ArrayList<>();
        for(int i = 0; i < ctx.attributeName().size(); i++) {
            KeyValue<String, String> pair = new KeyValue<>(ctx.attributeName(i).getText(), ctx.string(i).getText());
            pairs.add(pair);
        }
        core.Update(relation, new Condition(ctx.condition()), pairs);
    }

    @Override
    public void exitUpdate(DMLParser.UpdateContext ctx) {
    }

    // --------------------- INSERT ---------------------- //
    @Override
    public void enterInsert(DMLParser.InsertContext ctx) {
    }

    @Override
    public void exitInsert(DMLParser.InsertContext ctx) {
        if (ctx.expression() != null) {
            Relation values = pop();
            Relation relation = relations.get(ctx.relationName().getText());
            if(relation == null) throw new InvalidRelationNameException(ctx.relationName().getText());
            core.Insert(relation, values);
        } else {
            List<Object> values = new ArrayList<>();
            for (DMLParser.StringContext s : ctx.string())
                values.add(getValue(s.getText()));
            Relation relation = relations.get(ctx.relationName().getText());
            if(relation == null) throw new InvalidRelationNameException(ctx.relationName().getText());
            core.Insert(relation, values);
        }
    }

    // --------------------- DELETE ---------------------- //
    @Override
    public void enterDelete(DMLParser.DeleteContext ctx) {
        Relation relation = relations.get(ctx.relationName().getText());
        if(relation == null) throw new InvalidRelationNameException(ctx.relationName().getText());
        core.Delete(relation, new Condition(ctx.condition()));
    }

    @Override
    public void exitDelete(DMLParser.DeleteContext ctx) {
    }


    /// ------------------------------------------------- ///
    /////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////
    /*			Just ignore everything below here          */
    /////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////
    /// ------------------------------------------------- ///

    // --------------- TYPEDATTRIBUTELIST ---------------- //
    @Override
    public void enterTypedAttributeList(DMLParser.TypedAttributeListContext ctx) {
    }

    @Override
    public void exitTypedAttributeList(DMLParser.TypedAttributeListContext ctx) {
    }

    // --------------------- TYPE ------------------------ //
    @Override
    public void enterType(DMLParser.TypeContext ctx) {
    }

    @Override
    public void exitType(DMLParser.TypeContext ctx) {
    }

    // --------------------- CONDITION ------------------ //
    @Override
    public void enterCondition(DMLParser.ConditionContext ctx) {
    }

    @Override
    public void exitCondition(DMLParser.ConditionContext ctx) {
    }

    // --------------------- CONJUNCTION ---------------- //
    @Override
    public void enterConjunction(DMLParser.ConjunctionContext ctx) {
    }

    @Override
    public void exitConjunction(DMLParser.ConjunctionContext ctx) {
    }

    // --------------------- COMPARISON ----------------- //
    @Override
    public void enterComparison(DMLParser.ComparisonContext ctx) {
    }

    @Override
    public void exitComparison(DMLParser.ComparisonContext ctx) {
    }

    // --------------------- OPERATOR ------------------- //
    @Override
    public void enterOperator(DMLParser.OperatorContext ctx) {
    }

    @Override
    public void exitOperator(DMLParser.OperatorContext ctx) {
    }

    // --------------------- OPERAND -------------------- //
    @Override
    public void enterOperand(DMLParser.OperandContext ctx) {
    }

    @Override
    public void exitOperand(DMLParser.OperandContext ctx) {
    }

    // --------------------- ATTRIBUTENAME -------------- //
    @Override
    public void enterAttributeName(DMLParser.AttributeNameContext ctx) {
    }

    @Override
    public void exitAttributeName(DMLParser.AttributeNameContext ctx) {
    }

    // --------------------- EXPRESSION ----------------- //
    @Override
    public void enterExpression(DMLParser.ExpressionContext ctx) {
    }

    @Override
    public void exitExpression(DMLParser.ExpressionContext ctx) {
    }

    // --------------------- ATOMICEXPRESSION ----------- //
    @Override
    public void enterAtomicExpression(DMLParser.AtomicExpressionContext ctx) {
    }

    @Override
    public void exitAtomicExpression(DMLParser.AtomicExpressionContext ctx) {
    }

    // --------------------- PROGRAM -------------------- //
    @Override
    public void enterProgram(DMLParser.ProgramContext ctx) {
    }

    @Override
    public void exitProgram(DMLParser.ProgramContext ctx) {
    }

    // --------------------- STRING --------------------- //
    @Override
    public void enterString(DMLParser.StringContext ctx) {
    }

    @Override
    public void exitString(DMLParser.StringContext ctx) {
    }

    // --------------------- COMMAND -------------------- //
    @Override
    public void enterCommand(DMLParser.CommandContext ctx) {
    }

    @Override
    public void exitCommand(DMLParser.CommandContext ctx) {
    }

    // --------------------- RELATIONNAME --------------- //
    @Override
    public void enterRelationName(DMLParser.RelationNameContext ctx) {
    }

    @Override
    public void exitRelationName(DMLParser.RelationNameContext ctx) {
    }

    // --------------------- ATTRIBUTELIST -------------- //
    @Override
    public void enterAttributeList(DMLParser.AttributeListContext ctx) {
    }

    @Override
    public void exitAttributeList(DMLParser.AttributeListContext ctx) {
    }

    @Override
    public void enterEveryRule(ParserRuleContext ctx) {
    }

    @Override
    public void exitEveryRule(ParserRuleContext ctx) {
    }

    @Override
    public void visitTerminal(TerminalNode node) {
    }

    @Override
    public void visitErrorNode(ErrorNode node) {
    }
}


//check 
