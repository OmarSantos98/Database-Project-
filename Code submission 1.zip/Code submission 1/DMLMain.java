import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;

public class DMLMain {
    
    public static void main(String args[]) throws IOException {
		
        
     	//DMLReader.readInput();
        
        
     UnitTesting.isValid(); 
        
    }
}