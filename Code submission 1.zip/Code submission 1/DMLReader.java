import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;

public class DMLReader {
    
    public static void readInput() throws IOException{
    
		// Read one-line each from the input-stream, terminate on EOF.
	BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
	String line = null;
	int count = 0;
	while ((line = buffer.readLine()) != null) {
	    if (line.trim().equals("")) continue;
	    count++;
	    DMLErrorListener.ERROR = false;
	    // Lower-case the read line, create an antlr CharStream from that line
	    // and pass it to the lexer and parser.
	    CharStream stream = CharStreams.fromReader(new StringReader(line.toLowerCase()));
	    DMLLexer lexer = new DMLLexer(stream);
	    TokenStream tokenStream = new CommonTokenStream(lexer);
	    DMLParser parser = new DMLParser(tokenStream);
	    // Install the custom error listener to the parser.
	    // On a syntax error, the custom error listener will print the error message
	    // and set an ERROR flag to true.
		parser.removeErrorListeners();
	    parser.addErrorListener(DMLErrorListener.INSTANCE);
	    ParseTree tree = parser.program();
		
	    if (DMLErrorListener.ERROR) {
		System.out.println("Line " + count + " is invalid");
	    } else {
		System.out.println("Line " + count + " is valid");
	    }
	}
    }
    
}