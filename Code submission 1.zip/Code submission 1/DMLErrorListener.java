import org.antlr.v4.runtime.*;

public class DMLErrorListener extends BaseErrorListener {
    
    public static final DMLErrorListener INSTANCE = new DMLErrorListener();
    public static boolean ERROR = false;
    
    @Override
    public void syntaxError(Recognizer<?, ?> recognizer,
			    Object offendingSymbol, int line,
			    int charPositionInLine, String msg,
			    RecognitionException e) {

	ERROR = true;
    }
}
