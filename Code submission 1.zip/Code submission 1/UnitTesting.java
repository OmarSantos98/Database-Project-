import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;
import java.util.Vector;

public class UnitTesting {
    
	// Read one-line each from the input-stream, terminate on EOF.
	public static void isValid() throws IOException {
        BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
        String line = null;
        int count = 0;
        while ((line = buffer.readLine()) != null) {
            if (line.trim().equals("")) continue;
            count++;
            // Lower-case the read line, create an antlr CharStream from that line
            // and pass it to the lexer and parser.
            CharStream stream = new ANTLRInputStream(new StringReader(line.toLowerCase()));
            DMLLexer lexer = new DMLLexer(stream);
            TokenStream tokenStream = new CommonTokenStream(lexer);
            DMLParser parser = new DMLParser(tokenStream);
            // Install the custom error listener to the parser.
            // On a syntax error, the custom error listener will print the error message
            // and set an ERROR flag to true.
            parser.removeErrorListeners();
            parser.addErrorListener(DMLErrorListener.INSTANCE);
            ParseTree tree = parser.program();
            // If the ERROR flag is set, exit the loop and the program.
            //if (DMLErrorListener.ERROR) break;
            // If there was no parsing error, print the AST.
            //System.out.println(tree.toStringTree(parser));

            if (DMLErrorListener.ERROR) {
                System.out.println("Line " + count + " is invalid");
            } else {
                System.out.println("Line " + count + " is valid");
            }
        }
    }
};