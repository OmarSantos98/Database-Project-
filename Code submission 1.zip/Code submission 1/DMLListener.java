// Generated from DML.g4 by ANTLR 4.7.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link DMLParser}.
 */
public interface DMLListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link DMLParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(DMLParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(DMLParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#query}.
	 * @param ctx the parse tree
	 */
	void enterQuery(DMLParser.QueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#query}.
	 * @param ctx the parse tree
	 */
	void exitQuery(DMLParser.QueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#relationName}.
	 * @param ctx the parse tree
	 */
	void enterRelationName(DMLParser.RelationNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#relationName}.
	 * @param ctx the parse tree
	 */
	void exitRelationName(DMLParser.RelationNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#string}.
	 * @param ctx the parse tree
	 */
	void enterString(DMLParser.StringContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#string}.
	 * @param ctx the parse tree
	 */
	void exitString(DMLParser.StringContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpression(DMLParser.ExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpression(DMLParser.ExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#atomicExpression}.
	 * @param ctx the parse tree
	 */
	void enterAtomicExpression(DMLParser.AtomicExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#atomicExpression}.
	 * @param ctx the parse tree
	 */
	void exitAtomicExpression(DMLParser.AtomicExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#selection}.
	 * @param ctx the parse tree
	 */
	void enterSelection(DMLParser.SelectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#selection}.
	 * @param ctx the parse tree
	 */
	void exitSelection(DMLParser.SelectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#condition}.
	 * @param ctx the parse tree
	 */
	void enterCondition(DMLParser.ConditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#condition}.
	 * @param ctx the parse tree
	 */
	void exitCondition(DMLParser.ConditionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#conjunction}.
	 * @param ctx the parse tree
	 */
	void enterConjunction(DMLParser.ConjunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#conjunction}.
	 * @param ctx the parse tree
	 */
	void exitConjunction(DMLParser.ConjunctionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#comparison}.
	 * @param ctx the parse tree
	 */
	void enterComparison(DMLParser.ComparisonContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#comparison}.
	 * @param ctx the parse tree
	 */
	void exitComparison(DMLParser.ComparisonContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#operator}.
	 * @param ctx the parse tree
	 */
	void enterOperator(DMLParser.OperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#operator}.
	 * @param ctx the parse tree
	 */
	void exitOperator(DMLParser.OperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#operand}.
	 * @param ctx the parse tree
	 */
	void enterOperand(DMLParser.OperandContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#operand}.
	 * @param ctx the parse tree
	 */
	void exitOperand(DMLParser.OperandContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#attributeName}.
	 * @param ctx the parse tree
	 */
	void enterAttributeName(DMLParser.AttributeNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#attributeName}.
	 * @param ctx the parse tree
	 */
	void exitAttributeName(DMLParser.AttributeNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#projection}.
	 * @param ctx the parse tree
	 */
	void enterProjection(DMLParser.ProjectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#projection}.
	 * @param ctx the parse tree
	 */
	void exitProjection(DMLParser.ProjectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#attributeList}.
	 * @param ctx the parse tree
	 */
	void enterAttributeList(DMLParser.AttributeListContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#attributeList}.
	 * @param ctx the parse tree
	 */
	void exitAttributeList(DMLParser.AttributeListContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#rename}.
	 * @param ctx the parse tree
	 */
	void enterRename(DMLParser.RenameContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#rename}.
	 * @param ctx the parse tree
	 */
	void exitRename(DMLParser.RenameContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#union}.
	 * @param ctx the parse tree
	 */
	void enterUnion(DMLParser.UnionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#union}.
	 * @param ctx the parse tree
	 */
	void exitUnion(DMLParser.UnionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#difference}.
	 * @param ctx the parse tree
	 */
	void enterDifference(DMLParser.DifferenceContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#difference}.
	 * @param ctx the parse tree
	 */
	void exitDifference(DMLParser.DifferenceContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#product}.
	 * @param ctx the parse tree
	 */
	void enterProduct(DMLParser.ProductContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#product}.
	 * @param ctx the parse tree
	 */
	void exitProduct(DMLParser.ProductContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#naturalJoin}.
	 * @param ctx the parse tree
	 */
	void enterNaturalJoin(DMLParser.NaturalJoinContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#naturalJoin}.
	 * @param ctx the parse tree
	 */
	void exitNaturalJoin(DMLParser.NaturalJoinContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#command}.
	 * @param ctx the parse tree
	 */
	void enterCommand(DMLParser.CommandContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#command}.
	 * @param ctx the parse tree
	 */
	void exitCommand(DMLParser.CommandContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#open}.
	 * @param ctx the parse tree
	 */
	void enterOpen(DMLParser.OpenContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#open}.
	 * @param ctx the parse tree
	 */
	void exitOpen(DMLParser.OpenContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#close}.
	 * @param ctx the parse tree
	 */
	void enterClose(DMLParser.CloseContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#close}.
	 * @param ctx the parse tree
	 */
	void exitClose(DMLParser.CloseContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#write}.
	 * @param ctx the parse tree
	 */
	void enterWrite(DMLParser.WriteContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#write}.
	 * @param ctx the parse tree
	 */
	void exitWrite(DMLParser.WriteContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#exit}.
	 * @param ctx the parse tree
	 */
	void enterExit(DMLParser.ExitContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#exit}.
	 * @param ctx the parse tree
	 */
	void exitExit(DMLParser.ExitContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#show}.
	 * @param ctx the parse tree
	 */
	void enterShow(DMLParser.ShowContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#show}.
	 * @param ctx the parse tree
	 */
	void exitShow(DMLParser.ShowContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#create}.
	 * @param ctx the parse tree
	 */
	void enterCreate(DMLParser.CreateContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#create}.
	 * @param ctx the parse tree
	 */
	void exitCreate(DMLParser.CreateContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#update}.
	 * @param ctx the parse tree
	 */
	void enterUpdate(DMLParser.UpdateContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#update}.
	 * @param ctx the parse tree
	 */
	void exitUpdate(DMLParser.UpdateContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#insert}.
	 * @param ctx the parse tree
	 */
	void enterInsert(DMLParser.InsertContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#insert}.
	 * @param ctx the parse tree
	 */
	void exitInsert(DMLParser.InsertContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#delete}.
	 * @param ctx the parse tree
	 */
	void enterDelete(DMLParser.DeleteContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#delete}.
	 * @param ctx the parse tree
	 */
	void exitDelete(DMLParser.DeleteContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#typedAttributeList}.
	 * @param ctx the parse tree
	 */
	void enterTypedAttributeList(DMLParser.TypedAttributeListContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#typedAttributeList}.
	 * @param ctx the parse tree
	 */
	void exitTypedAttributeList(DMLParser.TypedAttributeListContext ctx);
	/**
	 * Enter a parse tree produced by {@link DMLParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(DMLParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link DMLParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(DMLParser.TypeContext ctx);
}